
import { Stack } from 'expo-router';
export default function Layout() {
  return (
    <Stack screenOptions={{ headerShown: true }}>
      <Stack.Screen name="index" options={{ title: 'MediTrack' }} />
      <Stack.Screen name="add" options={{ title: 'Add Prescription' }} />
      <Stack.Screen name="reminders" options={{ title: 'Reminders' }} />
    </Stack>
  );
}
