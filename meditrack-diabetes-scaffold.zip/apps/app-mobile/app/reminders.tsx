
import React from 'react';
import { View, Text } from 'react-native';

export default function Reminders() {
  return (
    <View style={{ padding: 16 }}>
      <Text style={{ fontSize: 24, fontWeight: '600' }}>Reminders</Text>
      <Text>Upcoming doses and low-supply alerts will appear here.</Text>
    </View>
  );
}
